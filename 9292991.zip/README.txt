Caio Ramos - NUSP 9292991 - IME USP 2016

Para executar o jogo, deve-se ter previamente instalado a biblioteca padrão Allegro 5.
Um bom tutorial para isto é: http://www.rafaeltoledo.net/compilando-e-instalando-a-biblioteca-allegro-5-no-ubuntu/
Executar o Makefile com o comando 'make' para montar todos os arquivos.
Para executar o teste do jogo, rodar o comando 'make run1'. Sera usado o
argumento 0.017 e o arquivo 1.in. (Para efeito de teste dos limites da tela
use o comando 'make run2')
